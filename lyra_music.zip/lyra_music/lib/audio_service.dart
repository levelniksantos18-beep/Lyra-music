import 'package:flutter/services.dart';

class AudioService {
  // O nome do canal deve ser EXATAMENTE o mesmo definido no seu Kotlin
  static const MethodChannel _channel = MethodChannel('lyra_music/audio');

  // Função para dar Play/Pause ou ativar/desativar a engine de áudio
  Future<void> toggleEngine(bool enable) async {
    try {
      await _channel.invokeMethod('toggleEngine', {'enable': enable});
      print("Motor de áudio alterado: $enable");
    } on PlatformException catch (e) {
      print("Erro ao conectar com o controle nativo: ${e.message}");
    }
  }

  // Função para o ajuste de som (SubGrave / Ganho)
  Future<void> setSubBass(int gain) async {
    try {
      await _channel.invokeMethod('setSubBass', {'gain': gain});
      print("Ganho do SubBass ajustado para: $gain");
    } on PlatformException catch (e) {
      print("Erro ao ajustar o som: ${e.message}");
    }
  }
}
