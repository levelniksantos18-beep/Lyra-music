import 'package:flutter/material.dart';
import 'package:on_audio_query/on_audio_query.dart';
import 'scanner.dart';
import 'audio_service.dart';

void main() {
  runApp(const LyraMusicApp());
}

class LyraMusicApp extends StatelessWidget {
  const LyraMusicApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Lyra Music',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final MusicScanner _scanner = MusicScanner();
  final AudioService _audioService = AudioService(); // Instanciando nosso serviço
  
  List<SongModel> _songs = [];
  bool _isLoading = true;
  bool _isPlaying = false;
  double _bassGain = 0; // Controle de volume/grave

  @override
  void initState() {
    super.initState();
    _loadSongs();
  }

  Future<void> _loadSongs() async {
    final songs = await _scanner.fetchLocalSongs();
    setState(() {
      _songs = songs;
      _isLoading = false;
    });
  }

  void _togglePlayPause() {
    setState(() {
      _isPlaying = !_isPlaying;
    });
    // Chama o método nativo em Kotlin
    _audioService.toggleEngine(_isPlaying);
  }

  void _changeBass(double value) {
    setState(() {
      _bassGain = value;
    });
    // Envia o valor inteiro para o Kotlin (ex: 0 a 1000)
    _audioService.setSubBass(value.toInt());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Lyra Music'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              setState(() => _isLoading = true);
              _loadSongs();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _songs.isEmpty
                    ? const Center(child: Text('Nenhuma música encontrada.'))
                    : ListView.builder(
                        itemCount: _songs.length,
                        itemBuilder: (context, index) {
                          final song = _songs[index];
                          return ListTile(
                            leading: QueryArtworkWidget(
                              id: song.id,
                              type: ArtworkType.AUDIO,
                              nullArtworkWidget: const Icon(Icons.music_note, size: 40),
                            ),
                            title: Text(
                              song.title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            subtitle: Text(
                              song.artist ?? 'Artista Desconhecido',
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                            ),
                            onTap: () {
                              // Ao clicar na música, ativa a engine (Play)
                              if (!_isPlaying) {
                                _togglePlayPause();
                              }
                            },
                          );
                        },
                      ),
          ),
          
          // --- PAINEL DE CONTROLE DE ÁUDIO ---
          Container(
            padding: const EdgeInsets.all(16),
            color: Colors.grey[900],
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    IconButton(
                      iconSize: 48,
                      icon: Icon(_isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled),
                      color: Colors.blueAccent,
                      onPressed: _togglePlayPause,
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text("Ajuste de Som / Grave"),
                Slider(
                  value: _bassGain,
                  min: 0,
                  max: 1000,
                  divisions: 10,
                  activeColor: Colors.blueAccent,
                  label: _bassGain.round().toString(),
                  onChanged: _changeBass,
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
