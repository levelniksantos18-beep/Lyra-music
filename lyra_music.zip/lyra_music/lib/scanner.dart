import 'package:on_audio_query/on_audio_query.dart';

class MusicScanner {
  final OnAudioQuery _audioQuery = OnAudioQuery();

  // Solicita permissão e busca todas as músicas do armazenamento interno
  Future<List<SongModel>> fetchLocalSongs() async {
    bool hasPermission = await _audioQuery.permissionsRequest();
    
    if (!hasPermission) {
      return [];
    }

    return await _audioQuery.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );
  }
}
